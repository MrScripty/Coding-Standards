# Implementation review notes

## Ownership and boundary checks

The schema/interface remain the serialized shape authority and generate the
Python and tool definitions. The change replaces focused result fields under
interface 38. It neither changes request/state versions nor edits persisted
workflow records. Pure presentation uses the native pending result already
produced by the existing operation; it does not obtain fresh evidence, add an
Analysis evaluation, or silently invoke the next operation.

The page observation is unchanged: it hashes exact Analysis, section, and whole
section items using the existing canonical JSON encoding. Bounded sizing is
shared with standalone details and includes the continuation. Inline projection
only removes parent bindings after the larger standalone form has passed the
budget. Oversized work preserves a successful mutation and supplies an explicit
full-record selection rather than truncating, skipping, or repeating mutation.

Coverage work comes from its issued coverage-requirement continuation; consumer
and impact work retain obligation handles. Unknown facts are presented for an
explicit answer before subsequent obligations. Current head, stale context,
per-decision evidence and authorization, atomic batch publication, readiness,
apply and recovery owners remain unchanged.

The full diagnostic workload remains available. Lightweight status still uses
direct counts instead of constructing a full Analysis result. Public result
changes are synchronized with native/generated examples, cold MCP consumers,
version assertions and deployment instructions. Ordinary routing descriptions
now recommend existing read_many without exposing authoring tools or changing
routing qualification.

## Evidence boundaries

Measurements compare the same bounded fixture through real cold MCP processes.
They count tool calls and serialized domain JSON, not model-visible catalog
presentation, tokenizer output, billing, or general latency. Pending mutation
responses intentionally contain more than the previous counts-only response;
the observed reduction is over the complete decision interaction.

This is internal implementation review, not the independent external review
required before accepted integration. The available interpreter is 3.13.5 and
rpds-py is 2026.5.1; the supported lock requires 3.11/3.12 and rpds-py 2026.6.3.
The lock was not changed. The configured Codex client was not exercised.
