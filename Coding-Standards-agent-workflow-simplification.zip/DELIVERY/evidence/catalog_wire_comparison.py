"""Compare wire catalog JSON using each supplied checkout's own implementation.

Use the selected locked interpreter, then pass baseline and candidate directories.
This observes catalog bytes, not model-visible schemas or token billing.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

PROGRAM = '''import json
from pathlib import Path
from tools.standards_engine.standards_engine.mcp import tool_catalog
c = tool_catalog(Path.cwd(), purpose="authoring")
size = lambda value: len(json.dumps(value).encode("utf-8"))
print(json.dumps({
    "tools": len(c), "catalog_json_bytes": size(c),
    "descriptions_bytes": sum(len(t["description"].encode("utf-8")) for t in c),
    "input_schemas_json_bytes": sum(size(t["inputSchema"]) for t in c),
    "output_schemas_json_bytes": sum(size(t["outputSchema"]) for t in c),
}))
'''

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('candidate', type=Path)
    args = parser.parse_args()
    result = {}
    for name, root in [('before', args.baseline), ('after', args.candidate)]:
        output = subprocess.check_output(
            [sys.executable, '-c', PROGRAM], cwd=root.resolve(),
            env={**os.environ, 'PYTHONPATH': '.'}, text=True,
        )
        result[name] = json.loads(output)
    result['scope'] = 'Serialized authoring tools/list catalog only, not model-rendered definitions or token billing.'
    print(json.dumps(result, indent=2))
