"""Cross-version, cold-process retained-context check using two exact source trees."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

before = Path('/mnt/data/Coding-Standards-baseline')
after = Path('/mnt/data/Coding-Standards-work')
with tempfile.TemporaryDirectory(prefix='workflow-cutover-') as temporary:
    root = Path(temporary) / 'repository'
    subprocess.run(['git','clone','--quiet','--no-hardlinks',str(before),str(root)], check=True)
    common = '''from pathlib import Path
import json, sys
from tools.standards_engine.standards_engine import AgentToolFacade
from tools.standards_engine.tests.test_agent_workflow import reference_change, decisions
from tools.standards_engine.tests.test_review_workflow_ux import topic_change, decision
root=Path(sys.argv[1])
'''
    code = common + '''with AgentToolFacade.open_repository(root,purpose='authoring') as f:
    pending=f.propose({'change_set':topic_change(root,'cutover-work',4)})
    assert pending['status']=='needs-action',pending
    page=f.workflow_details({'analysis':pending['context'],'section':'pending_obligations'})
    complete=f.propose({'change_set':reference_change(root,'cutover-ready')})
    ready=f.review({'context':complete['context'],'decisions':decisions(root)})
    assert ready['status']=='ready',ready
    print(json.dumps({'pending':pending,'items':page['items'],'ready':ready}))
'''
    original = json.loads(subprocess.check_output([sys.executable,'-c',code,str(root)],cwd=before,env={**os.environ,'PYTHONPATH':str(before)},text=True))
    # The installed result contract is replaced; the store, canonical Git base,
    # proposal programs, evidence bytes and all retained handles are preserved.
    for name in ('a1-interface.toml','a1-contract.schema.json','generated/agent-tools.json'):
        path=Path('tools/standards_engine/contracts')/name
        shutil.copyfile(after/path,root/path)
    retained=Path(temporary)/'retained.json'; retained.write_text(json.dumps(original))
    code = common + '''original=json.loads(Path(sys.argv[2]).read_text())
with AgentToolFacade.open_repository(root,purpose='authoring') as f:
    historical=f.workflow_status({'context':original['pending']['context']})
    assert historical['status']=='needs-action',historical
    assert historical['context']==original['pending']['context']
    assert 'handle' not in historical['outcome'] and 'work' not in historical
    successor=f.resolve_many({'context':historical['context'],'submissions':[decision(root,x['obligation']) for x in original['items'][:2]]})
    assert successor['status']=='needs-action',successor
    assert successor['work']['total']==2,successor
    ready=f.workflow_status({'context':original['ready']['context']})
    assert ready['status']=='ready' and ready['context']==original['ready']['context'],ready
    assert [x['operation'] for x in ready['next_operations']]==['apply','revise']
    print(json.dumps({'before_interface':37,'after_interface':38,'historical_status':historical['status'],'retained_analysis_handle':True,'old_work_accepted_in_exact_old_context':True,'successor_work_total':2,'retained_readiness_handle':True,'readiness_status':ready['status'],'migration_or_store_deletion':False},indent=2))
'''
    print(subprocess.check_output([sys.executable,'-c',code,str(root),str(retained)],cwd=after,env={**os.environ,'PYTHONPATH':str(after)},text=True))
