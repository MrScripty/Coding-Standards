# Coding-Standards agent workflow simplification

Base: `c4470f9e683da1e494eeeac3497e72e079221bac`. Interface: **38**. Changed/new repository files: **28**.
Local delivery checkpoint: `00467e14a95e790efdd36b51d38a73d731945c88`. No remote commit, push, merge or user-store
mutation was performed. Local commits only make the patch and test evidence exact.

The ZIP contains complete changed/new files at repository-relative paths. This
`DELIVERY/` directory is packaging metadata, not a required repository addition.
Use the patch for a conflict-aware integration rather than overwriting unrelated work.

## Integrate

1. Extract the ZIP to a separate directory. In your repository, inspect current
   changes and select a review branch. The patch targets the base above; later
   independent edits may require reconciliation.
2. From your repository root, using the real path to the extracted package:

   ```sh
   git apply --check /path/to/extracted/DELIVERY/changes.patch
   git apply /path/to/extracted/DELIVERY/changes.patch
   git diff --check
   ```

   A failing preflight means the patch needs reconciliation. Preserve unrelated
   edits; do not force replacement of the working tree. `manifest.json` lists
   base and updated SHA-256 digests for every delivered source file.
3. Verify with the existing supported Python 3.11/3.12 environment installed from
   `tools/standards_contracts/requirements.lock`, retaining hashes and pins:

   ```sh
   PYTHONPATH=. /path/to/locked-python -P -m tools.standards_contracts.standards_contracts.projection --check
   PYTHONPATH=. /path/to/locked-python -m unittest discover -s tools/standards_engine/tests
   PYTHONPATH=. /path/to/locked-python -m unittest discover -s tools/standards_contracts/tests
   printf '%s\n' '{"kind":"verify-repository","refresh_verification_inputs":false}' | \
     PYTHONPATH=. /path/to/locked-python -P .agents/skills/standards-engine/scripts/invoke.py \
       --purpose authoring verify_repository
   ```

   Inspect `verification.passed`; a zero transport exit alone is not acceptance.
   The report names the additional package suites and actual-client checks.
4. Complete the supported-runtime, configured-client and independent-review
   gates documented in `docs/plans/agent-workflow-simplification/verification.md`.
   Review and commit the exact diff through the repository's ordinary process.
5. Restart the MCP server and reconnect/refresh clients. Confirm interface 38 via
   `runtime_info`. Keep existing workflow stores and exact handles; no migration,
   reset or data deletion is needed. Do not mix an old catalog with the new result
   shape.

## Main behavior

Successful compact pending mutations supply the first bounded work page. Follow
relative page selections with `analysis` from the enclosing context, and submit
actual ready decisions with `resolve_many`. Missing facts are presented first.
`workflow_status` remains lightweight: a caller resuming from status reads its
first needed detail page explicitly. Full diagnostic reads remain available.
Focused continuation arguments inherit the result's exact context. Review,
publication, evidence validation, stale-context behavior and recovery stay explicit.

## Qualification limits

Local tests used Python 3.13.5 and rpds-py 2026.5.1, not the supported locked runtime.
The exact-environment contract test skipped. The configured Codex client and an
independent external reviewer were not available. The plan therefore remains
Verifying, rather than Accepted. Test logs, the resolved test-client failure,
before/after cold-MCP traces and retained-handle evidence are included.
The byte measurements are serialized domain JSON, not model tokens or billing.
